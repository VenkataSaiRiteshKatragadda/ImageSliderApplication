//
//  ViewController.swift
//  imageAssignment
//
//  Created by ritesh Chowdary on 6/16/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var i: Int = 0
    var j: Int = 8
    var n: Int = 0
    var time: Timer?
    var flag: String = ""
    @IBOutlet weak var imgView: UIImageView!
    let images = [#imageLiteral(resourceName: "jodhpur.jpg"),#imageLiteral(resourceName: "kakadu.jpg"),#imageLiteral(resourceName: "ladakh.jpg"),#imageLiteral(resourceName: "las-vegas.jpg"),#imageLiteral(resourceName: "london.jpg"),#imageLiteral(resourceName: "melbourne.jpg"),#imageLiteral(resourceName: "montreal.jpg"),#imageLiteral(resourceName: "new-york.jpg"),#imageLiteral(resourceName: "niagara-falls.jpg")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imgView.image = images[0]
        let one = UITapGestureRecognizer(target: self, action:#selector(self.tap(_:)))
        one.numberOfTapsRequired = 1
        view.addGestureRecognizer(one)

        let two = UITapGestureRecognizer(target: self, action:#selector(self.tap(_:)))
        two.numberOfTapsRequired = 2
        view.addGestureRecognizer(two)
        
        let rightside = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture(_:)))
        let leftside = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture(_:)))
        rightside.direction = UISwipeGestureRecognizer.Direction.right
        leftside.direction = UISwipeGestureRecognizer.Direction.left
        view.addGestureRecognizer(rightside)
        view.addGestureRecognizer(leftside)
    }
    
    
        
        
    
    
    
    
    @objc func swipeGesture(_ sender : UISwipeGestureRecognizer){
        if sender.direction == UISwipeGestureRecognizer.Direction.right
        {
            if i < 8
            {
                i += 1
            }
            else if i == 8
            {
                i = 0
            }
            imgView.image = images[i]
            n = i
        }
        else if sender.direction == UISwipeGestureRecognizer.Direction.left
        {
            if j > 0
            {
                j -= 1
            }
            if j <= 0
            {
                j = 8
            }
            imgView.image = images[j]
            n = j
        }
        else
        {
            time = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true, block: { (time) in
                    
            
                    if self.i < 8
                    {
                        self.i += 1
                    }
                    else if self.i == 8
                    {
                        self.i = 0
                    }
                    self.imgView.image = self.images[self.i]
                self.n = self.i
                })
        }
        

  
}

@objc func tap(_ sender:UITapGestureRecognizer){

    if sender.numberOfTapsRequired == 2
    {
    time = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true, block: { (time) in
            
    
            if self.i < 8
            {
                self.i += 1
            }
            else if self.i == 8
            {
                self.i = 0
            }
            self.imgView.image = self.images[self.i]
        self.n = self.i
            
        }
    )}
    else if sender.numberOfTapsRequired == 1
    {
        imgView.image = images[n]
    }
    }


}

